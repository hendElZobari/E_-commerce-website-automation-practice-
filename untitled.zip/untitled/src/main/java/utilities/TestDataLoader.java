package utilities;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.FileReader;

public class TestDataLoader {
    private static JsonObject testData;

    static {
        try {
            FileReader reader = new FileReader("src/resources/testdata.json");
            testData = JsonParser.parseReader(reader).getAsJsonObject();
        } catch (Exception e) {
            throw new RuntimeException("Failed to load testdata.json!", e);
        }
    }

    public static String get(String key) {
        return testData.get(key).getAsString();
    }
}
