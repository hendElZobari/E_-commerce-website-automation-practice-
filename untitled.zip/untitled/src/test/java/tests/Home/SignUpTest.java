package tests.Home;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.*;

public class SignUpTest {

    WebDriver driver;

    @BeforeClass
    public void setup() {
        System.setProperty("webdriver.chrome.driver", "drivers/chromedriver.exe"); // Set your path
        driver = new ChromeDriver();
        driver.manage().window().maximize();
    }

    @Test
    public void testSignUpSuccess() throws InterruptedException {
        driver.get("https://www.demoblaze.com");

        // Open Sign Up modal
        driver.findElement(By.id("signin2")).click();
        Thread.sleep(2000);  // Wait for modal to open

        // Enter new username and password for sign-up
        String username = "newUser" + System.currentTimeMillis();  // Unique username
        String password = "newPassword123";

        driver.findElement(By.id("sign-username")).sendKeys(username);
        driver.findElement(By.id("sign-password")).sendKeys(password);

        // Click "Sign up"
        driver.findElement(By.xpath("//button[text()='Sign up']")).click();
        Thread.sleep(3000);

        // Handle success or failure alert
        Alert alert = driver.switchTo().alert();
        String alertText = alert.getText();

        if (alertText.contains("Sign up successful")) {
            alert.accept();
            Assert.assertTrue(true, "Sign up successful!");
        } else if (alertText.contains("This user already exists")) {
            alert.accept();
            Assert.assertTrue(false, "Username already exists.");
        } else {
            alert.accept();
            Assert.fail("Unexpected alert message: " + alertText);
        }
    }

    @Test
    public void testSignUpFailure() throws InterruptedException {
        driver.get("https://www.demoblaze.com");

        // Open Sign Up modal
        driver.findElement(By.id("signin2")).click();
        Thread.sleep(2000);  // Wait for modal to open

        // Use an already existing username (change this based on your data)
        String username = "existingUser";
        String password = "newPassword123";

        driver.findElement(By.id("sign-username")).sendKeys(username);
        driver.findElement(By.id("sign-password")).sendKeys(password);

        // Click "Sign up"
        driver.findElement(By.xpath("//button[text()='Sign up']")).click();
        Thread.sleep(3000);

        // Handle alert for already existing username
        Alert alert = driver.switchTo().alert();
        String alertText = alert.getText();

        if (alertText.contains("This user already exists")) {
            alert.accept();
            Assert.assertTrue(true, "Username already exists.");
        } else {
            alert.accept();
            Assert.fail("Unexpected alert message: " + alertText);
        }
    }

    @AfterClass
    public void tearDown() {
        driver.quit();
    }
}