package tests;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class ApiLoginTest {

    @BeforeClass
    public void setup() {
        // Set base URI before tests run
        RestAssured.baseURI = "https://api.demoblaze.com";
    }

    @Test
    public void testValidLogin() {
        String payload = "{\n" +
                "    \"username\": \"testuser1\",\n" +
                "    \"password\": \"hashedpassword1\"\n" +
                "}";

        Response response = RestAssured
                .given()
                .contentType(ContentType.JSON)
                .body(payload)
                .when()
                .post("/login");

        // Log the response
        System.out.println("Response: " + response.getBody().asString());

        // Assert: status code
        Assert.assertEquals(response.statusCode(), 200, "Expected status code 200");

        // Assert: contains Auth token or user ID
        String responseBody = response.getBody().asString();
        Assert.assertTrue(responseBody.contains("Auth_token") || responseBody.contains("token") || responseBody.contains("id"),
                "Expected a token or ID in login response");
    }

    @Test
    public void testInvalidLogin() {
        String payload = "{\n" +
                "    \"username\": \"wronguser\",\n" +
                "    \"password\": \"wrongpass\"\n" +
                "}";

        Response response = RestAssured
                .given()
                .contentType(ContentType.JSON)
                .body(payload)
                .when()
                .post("/login");

        System.out.println("Invalid Login Response: " + response.getBody().asString());

        Assert.assertEquals(response.statusCode(), 200, "Expected 200 (Demoblaze always returns 200)");

        // Check error message
        Assert.assertTrue(response.getBody().asString().contains("error"),
                "Expected error message for invalid login");
    }
}