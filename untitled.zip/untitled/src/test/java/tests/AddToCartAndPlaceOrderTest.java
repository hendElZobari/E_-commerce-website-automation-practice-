package tests;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.*;

public class AddToCartAndPlaceOrderTest {

    WebDriver driver;

    @BeforeClass
    public void setup() {
        System.setProperty("webdriver.chrome.driver", "drivers/chromedriver.exe"); // Set your path
        driver = new ChromeDriver();
        driver.manage().window().maximize();
    }

    @Test
    public void testAddToCartAndPlaceOrder() throws InterruptedException {
        driver.get("https://www.demoblaze.com");

        // Click on the "Samsung galaxy s6" product (you can change the product)
        driver.findElement(By.linkText("Samsung galaxy s6")).click();
        Thread.sleep(3000);

        // Click on the "Add to cart" button
        driver.findElement(By.linkText("Add to cart")).click();
        Thread.sleep(3000);

        // Handle the alert that pops up when the item is added to the cart
        Alert alert = driver.switchTo().alert();
        String alertText = alert.getText();
        Assert.assertTrue(alertText.contains("Product added"), "Alert text does not contain 'Product added'");
        alert.accept();

        // Go to the cart
        driver.findElement(By.id("cartur")).click();
        Thread.sleep(3000);

        // Click on the "Place Order" button
        driver.findElement(By.xpath("//button[text()='Place Order']")).click();
        Thread.sleep(2000);

        // Fill in the order form
        driver.findElement(By.id("name")).sendKeys("John Doe");
        driver.findElement(By.id("country")).sendKeys("USA");
        driver.findElement(By.id("city")).sendKeys("New York");
        driver.findElement(By.id("card")).sendKeys("4111111111111111");
        driver.findElement(By.id("month")).sendKeys("04");
        driver.findElement(By.id("year")).sendKeys("2025");

        // Click the "Purchase" button
        driver.findElement(By.xpath("//button[text()='Purchase']")).click();
        Thread.sleep(3000);

        // Handle confirmation message
        WebElement confirmationMessage = driver.findElement(By.className("sweet-alert"));
        Assert.assertTrue(confirmationMessage.isDisplayed(), "Order confirmation not displayed");

        // Click "OK" on the confirmation message
        driver.findElement(By.xpath("//button[text()='OK']")).click();
    }

    @AfterClass
    public void tearDown() {
        driver.quit();
    }
}