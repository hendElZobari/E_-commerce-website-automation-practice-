package tests.login;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.*;

public class loginTestCase {

    WebDriver driver;

    @BeforeClass
    public void setup() {
        // Set the path to your ChromeDriver executable
        System.setProperty("webdriver.chrome.driver", "path/to/chromedriver");
        driver = new ChromeDriver();
        driver.manage().window().maximize();
    }

    @Test
    public void loginTest() throws InterruptedException {
        // Navigate to Demoblaze website
        driver.get("https://www.demoblaze.com");

        // Click on the "Log in" button to open the login modal
        WebElement loginButton = driver.findElement(By.id("login2"));
        loginButton.click();

        // Wait for the modal to appear
        Thread.sleep(2000); // Consider using WebDriverWait for better practice

        // Enter username
        WebElement usernameField = driver.findElement(By.id("loginusername"));
        usernameField.sendKeys("your_username");

        // Enter password
        WebElement passwordField = driver.findElement(By.id("loginpassword"));
        passwordField.sendKeys("your_password");

        // Click on the "Log in" button within the modal
        WebElement modalLoginButton = driver.findElement(By.xpath("//button[text()='Log in']"));
        modalLoginButton.click();

        // Wait for login to process
        Thread.sleep(3000); // Consider using WebDriverWait for better practice

        // Verify that "Log out" button is displayed, indicating a successful login
        WebElement logoutButton = driver.findElement(By.id("logout2"));
        Assert.assertTrue(logoutButton.isDisplayed(), "Login failed: 'Log out' button not found.");
    }

    @AfterClass
    public void teardown() {
        // Close the browser
        driver.quit();
    }
}

