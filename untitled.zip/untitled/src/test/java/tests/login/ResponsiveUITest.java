package tests.login;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.Assert;
import org.testng.annotations.*;

import java.util.HashMap;
import java.util.Map;

public class ResponsiveUITest {

    WebDriver driver;

    @BeforeClass
    public void setup() {
        System.setProperty("webdriver.chrome.driver", "drivers/chromedriver.exe");  // Change path if needed
        ChromeOptions options = new ChromeOptions();
        driver = new ChromeDriver(options);
    }

    @Test
    @Parameters({"deviceType"})
    public void testResponsiveUI(String deviceType) throws InterruptedException {
        driver.get("https://www.demoblaze.com");

        // Simulate device viewport
        switch (deviceType) {
            case "mobile":
                simulateMobile();
                break;
            case "tablet":
                simulateTablet();
                break;
            case "desktop":
                simulateDesktop();
                break;
            default:
                throw new IllegalArgumentException("Unknown device type: " + deviceType);
        }

        // Verify UI layout
        verifyLayout();

        // Optional pause
        Thread.sleep(2000);
    }

    private void simulateMobile() {
        Map<String, Object> deviceMetrics = new HashMap<>();
        deviceMetrics.put("width", 375);
        deviceMetrics.put("height", 667);
        deviceMetrics.put("mobile", true);
        deviceMetrics.put("deviceScaleFactor", 50);

        ((ChromeDriver) driver).executeCdpCommand("Emulation.setDeviceMetricsOverride", deviceMetrics);
        System.out.println("Simulating Mobile...");
    }

    private void simulateTablet() {
        Map<String, Object> deviceMetrics = new HashMap<>();
        deviceMetrics.put("width", 768);
        deviceMetrics.put("height", 1024);
        deviceMetrics.put("mobile", true);
        deviceMetrics.put("deviceScaleFactor", 50);

        ((ChromeDriver) driver).executeCdpCommand("Emulation.setDeviceMetricsOverride", deviceMetrics);
        System.out.println("Simulating Tablet...");
    }

    private void simulateDesktop() {
        Map<String, Object> deviceMetrics = new HashMap<>();
        deviceMetrics.put("width", 1920);
        deviceMetrics.put("height", 1080);
        deviceMetrics.put("mobile", false);
        deviceMetrics.put("deviceScaleFactor", 100);

        ((ChromeDriver) driver).executeCdpCommand("Emulation.setDeviceMetricsOverride", deviceMetrics);
        System.out.println("Simulating Desktop...");
    }

    private void verifyLayout() {
        // Navbar check
        WebElement navbar = driver.findElement(By.className("navbar"));
        Assert.assertTrue(navbar.isDisplayed(), "Navbar is not displayed.");

        // Product card check
        WebElement firstProduct = driver.findElement(By.cssSelector(".card-block"));
        Assert.assertTrue(firstProduct.isDisplayed(), "First product is not visible.");

        // Optional CSS size check
        String width = firstProduct.getCssValue("width");
        Assert.assertNotEquals(width, "0px", "Product width is zero.");
    }

    @AfterClass
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}
