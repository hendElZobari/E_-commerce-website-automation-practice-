package tests.login;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.devtools.DevTools;
import org.openqa.selenium.devtools.v112.device.DeviceMetrics;
import org.openqa.selenium.devtools.v112.device.DeviceOrientation;
import org.openqa.selenium.devtools.v112.device.DeviceScreenResolution;
import org.openqa.selenium.devtools.v112.device.DeviceType;
import org.testng.Assert;
import org.testng.annotations.*;

public class ResponsiveUITest {

    WebDriver driver;
    DevTools devTools;

    @BeforeClass
    public void setup() {
        System.setProperty("webdriver.chrome.driver", "drivers/chromedriver.exe");  // Set your path
        ChromeOptions options = new ChromeOptions();
        driver = new ChromeDriver(options);

        // Enable Chrome DevTools Protocol
        devTools = ((ChromeDriver) driver).getDevTools();
        devTools.createSession();
    }

    @Test
    @Parameters({"deviceType"})
    public void testResponsiveUI(String deviceType) throws InterruptedException {
        driver.get("https://www.demoblaze.com");

        // Resize based on device type
        switch (deviceType) {
            case "mobile":
                simulateMobile();
                break;
            case "tablet":
                simulateTablet();
                break;
            case "desktop":
                simulateDesktop();
                break;
            default:
                throw new IllegalArgumentException("Unknown device type: " + deviceType);
        }

        // Verify layout elements (e.g., navbar, product cards)
        verifyLayout();

        // Wait for user to inspect results (optional)
        Thread.sleep(2000);
    }

    private void simulateMobile() {
        // Set viewport for mobile device (e.g., iPhone 6)
        devTools.send(DeviceMetrics.setDeviceMetricsOverride(375, 667, 50, true, DeviceOrientation.PORTRAIT, DeviceType.MOBILE));
        System.out.println("Simulating Mobile...");
    }

    private void simulateTablet() {
        // Set viewport for tablet device (e.g., iPad)
        devTools.send(DeviceMetrics.setDeviceMetricsOverride(768, 1024, 50, true, DeviceOrientation.PORTRAIT, DeviceType.TABLET));
        System.out.println("Simulating Tablet...");
    }

    private void simulateDesktop() {
        // Set viewport for desktop (e.g., 1920x1080)
        devTools.send(DeviceMetrics.setDeviceMetricsOverride(1920, 1080, 50, false, DeviceOrientation.PORTRAIT, DeviceType.DESKTOP));
        System.out.println("Simulating Desktop...");
    }

    private void verifyLayout() {
        // Check if navbar is visible
        WebElement navbar = driver.findElement(By.className("navbar"));
        Assert.assertTrue(navbar.isDisplayed(), "Navbar is not displayed.");

        // Check if product cards are visible (checking a few product cards)
        WebElement firstProduct = driver.findElement(By.cssSelector(".card-block"));
        WebElement secondProduct = driver.findElement(By.cssSelector(".card-block:nth-child(2)"));
        Assert.assertTrue(firstProduct.isDisplayed(), "First product is not visible.");
        Assert.assertTrue(secondProduct.isDisplayed(), "Second product is not visible.");

        // Optional: Check layout responsiveness (could be based on specific styles, etc.)
        String firstProductWidth = firstProduct.getCssValue("width");
        Assert.assertNotEquals(firstProductWidth, "0px", "Product card width is zero.");
    }

    @AfterClass
    public void tearDown() {
        driver.quit();}
}
