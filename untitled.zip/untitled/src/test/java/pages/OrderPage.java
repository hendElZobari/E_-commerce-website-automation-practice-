package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class OrderPage {
    WebDriver driver;

    public OrderPage(WebDriver driver) {
        this.driver = driver;
    }

    // Locators for order modal
    By nameInput = By.id("name");
    By countryInput = By.id("country");
    By cityInput = By.id("city");
    By cardInput = By.id("card");
    By monthInput = By.id("month");
    By yearInput = By.id("year");
    By purchaseBtn = By.xpath("//button[text()='Purchase']");
    By confirmationBox = By.className("sweet-alert");
    By okButton = By.xpath("//button[text()='OK']");

    // Fill form fields
    public void fillOrderForm(String name, String country, String city, String card, String month, String year) {
        driver.findElement(nameInput).sendKeys(name);
        driver.findElement(countryInput).sendKeys(country);
        driver.findElement(cityInput).sendKeys(city);
        driver.findElement(cardInput).sendKeys(card);
        driver.findElement(monthInput).sendKeys(month);
        driver.findElement(yearInput).sendKeys(year);
    }

    // Click the "Purchase" button
    public void clickPurchase() {
        driver.findElement(purchaseBtn).click();
    }

    // Confirm SweetAlert success box is displayed
    public boolean isOrderConfirmed() {
        return driver.findElement(confirmationBox).isDisplayed();
    }

    // Optional: click the OK button on SweetAlert
    public void clickOk() {
        driver.findElement(okButton).click();
    }
}
