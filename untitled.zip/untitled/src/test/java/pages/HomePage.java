package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class HomePage {
    WebDriver driver;

    public HomePage(WebDriver driver) {
        this.driver = driver;
    }

    By productByName(String name) {
        return By.xpath("//a[text()='" + name + "']");
    }

    By addToCartBtn = By.xpath("//a[text()='Add to cart']");
    By cartLink = By.id("cartur");

    public void selectProduct(String productName) {
        driver.findElement(productByName(productName)).click();
    }

    public void clickAddToCart() {
        driver.findElement(addToCartBtn).click();
    }

    public void goToCart() {
        driver.findElement(cartLink).click();
    }
}