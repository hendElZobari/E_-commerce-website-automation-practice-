package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class SignUpPage {
    WebDriver driver;

    public SignUpPage(WebDriver driver) {
        this.driver = driver;
    }

    By signUpLink = By.id("signin2");
    By usernameInput = By.id("sign-username");
    By passwordInput = By.id("sign-password");
    By signUpBtn = By.xpath("//button[text()='Sign up']");

    public void openSignUpForm() {
        driver.findElement(signUpLink).click();
    }

    public void fillSignUpForm(String username, String password) {
        driver.findElement(usernameInput).sendKeys(username);
        driver.findElement(passwordInput).sendKeys(password);
    }

    public void clickSignUp() {
        driver.findElement(signUpBtn).click();
    }
}