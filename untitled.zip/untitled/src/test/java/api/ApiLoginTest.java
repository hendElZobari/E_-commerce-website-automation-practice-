package api;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.Test;

public class ApiLoginTest {

    @Test
    public void testSuccessfulLogin() {
        // Set the base URI
        RestAssured.baseURI = "https://api.demoblaze.com";

        // Create the JSON body
        String requestBody = "{\n" +
                "    \"username\": \"testuser1\",\n" +
                "    \"password\": \"hashedpassword1\"\n" +
                "}";

        // Send POST request to /login
        Response response = RestAssured
                .given()
                .contentType(ContentType.JSON)
                .body(requestBody)
                .when()
                .post("/login")
                .then()
                .extract().response();

        // Assert status code
        Assert.assertEquals(response.statusCode(), 200, "Status code is not 200");

        // Print and validate response body
        System.out.println("Response Body:");
        System.out.println(response.getBody().asString());

        // Basic body assertion (depends on API response format)
        Assert.assertTrue(response.getBody().asString().contains("Auth_token") ||
                        response.getBody().asString().contains("token"),
                "Login token not found in response");
    }
}
